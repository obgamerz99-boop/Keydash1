(() => {
  const body = document.body;
  const $ = (id) => document.getElementById(id);
  const queueButton = $('queue-button'), cancelButton = $('cancel-queue');
  const queueView = $('queue-view'), matchView = $('match-view'), input = $('online-input');
  let pollTimer = null, queueClock = null, queueStarted = 0, matchId = 0;
  let words = [], wordIndex = 0, startedAt = 0, active = false, finished = false;
  const music = $('background-music'), musicToggle = $('music-toggle'), soundToggle = $('typing-sound-toggle');
  let audioContext = null;
  music.volume = Number($('music-volume').value) / 100;
  function tone(frequency = 520, duration = .04, volume = .018) {
    if (soundToggle.getAttribute('aria-pressed') !== 'true') return;
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') audioContext.resume();
    const oscillator = audioContext.createOscillator(), gain = audioContext.createGain();
    oscillator.type = 'square'; oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(volume, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioContext.currentTime + duration);
    oscillator.connect(gain); gain.connect(audioContext.destination);
    oscillator.start(); oscillator.stop(audioContext.currentTime + duration);
  }
  function playMusic() { music.play().then(() => { musicToggle.setAttribute('aria-pressed', 'true'); musicToggle.lastElementChild.textContent = 'ON'; }).catch(() => { musicToggle.lastElementChild.textContent = 'TAP TO PLAY'; }); }
  musicToggle.addEventListener('click', () => { if (music.paused) playMusic(); else { music.pause(); musicToggle.lastElementChild.textContent = 'OFF'; } });
  $('music-volume').addEventListener('input', (event) => { music.volume = Number(event.target.value) / 100; });
  soundToggle.addEventListener('click', () => { const on = soundToggle.getAttribute('aria-pressed') !== 'true'; soundToggle.setAttribute('aria-pressed', String(on)); soundToggle.lastElementChild.textContent = on ? 'ON' : 'OFF'; if (on) tone(660); });
  if (body.dataset.loggedIn !== '1') return;
  function clock(seconds) { return `${String(Math.floor(seconds / 60)).padStart(2,'0')}:${String(seconds % 60).padStart(2,'0')}`; }
  async function api(action, data = {}) {
    const response = await fetch('online_api.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': body.dataset.csrf }, body: JSON.stringify({ action, ...data }) });
    const result = await response.json();
    if (!response.ok || result.error) throw new Error(result.error || 'Online match service error');
    return result;
  }
  function error(message) { $('online-error').textContent = message; $('online-error').hidden = false; }
  function clearError() { $('online-error').hidden = true; }
  function beginPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = setInterval(poll, 1200); }
  function stopPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }
  function showWaiting(data = {}) {
    queueView.hidden = false; matchView.hidden = true;
    queueButton.hidden = true; cancelButton.hidden = false;
    $('queue-title').textContent = 'Searching for an opponent…';
    $('queue-message').textContent = 'Keep this page open. We’ll start the shared round as soon as another player joins.';
    $('queue-timing').hidden = false;
    if (data.estimated_wait) $('queue-estimate').textContent = `Estimated wait: about ${data.estimated_wait} sec`;
    $('queue-count').textContent = Number(data.queue_count) > 0 ? `${data.queue_count} other player${Number(data.queue_count) === 1 ? '' : 's'} in queue` : 'Finding another player…';
    if (!queueStarted) queueStarted = Date.now();
    if (!queueClock) queueClock = setInterval(() => $('queue-elapsed').textContent = clock(Math.floor((Date.now() - queueStarted) / 1000)), 500);
    clearError();
  }
  function showIdle() {
    stopPolling(); if (queueClock) clearInterval(queueClock); queueClock = null; queueStarted = 0;
    queueView.hidden = false; matchView.hidden = true; queueButton.hidden = false; cancelButton.hidden = true;
    $('queue-timing').hidden = true; $('queue-title').textContent = 'Queue up for a duel.';
    $('queue-message').textContent = 'We’ll match you with the next available player.';
  }
  function paintWord() {
    const current = words[wordIndex];
    $('online-target').textContent = current ? current.word : 'Finished!';
    $('online-target').classList.remove('word-pop'); void $('online-target').offsetWidth; $('online-target').classList.add('word-pop');
    $('online-word-number').textContent = String(Math.min(wordIndex + 1, 10)).padStart(2, '0');
    $('online-word-level').textContent = current ? `${current.level.toUpperCase()} WORD` : 'ROUND COMPLETE';
    $('online-word-level').className = `online-word-level level-${current?.level || 'easy'}`;
    input.value = ''; input.classList.remove('is-wrong');
    $('online-my-words').textContent = `${wordIndex}/10`;
  }
  function showMatch(data) {
    if (queueClock) clearInterval(queueClock); queueClock = null; queueStarted = 0;
    queueView.hidden = true; matchView.hidden = false; cancelButton.hidden = true;
    if (matchId !== data.match_id) {
      matchId = data.match_id; words = Array.isArray(data.words) ? data.words : [];
      wordIndex = Number(data.my_words || 0); startedAt = Date.now(); active = true; finished = false;
      $('online-my-name').textContent = body.dataset.username;
      document.querySelector('.avatar-you').textContent = body.dataset.avatar || '⌨️';
      $('online-opponent-name').textContent = data.opponent || 'Opponent';
      document.querySelector('.avatar-bot').textContent = data.opponent_avatar || '⌨️';
      $('online-result').hidden = true; $('rematch-button').hidden = true; $('return-lobby').hidden = true;
      $('forfeit-button').hidden = false; input.disabled = false;
      paintWord(); input.focus();
    }
    updateScores(data);
    if (data.status === 'completed') showResult(data);
    clearError();
  }
  function updateScores(data) {
    const myWords = Number(data.my_words || 0), rivalWords = Number(data.opponent_words || 0);
    $('online-my-words').textContent = `${myWords}/10`; $('online-opponent-words').textContent = `${rivalWords}/10`;
    $('online-my-wpm').textContent = `${Number(data.my_wpm || 0)} WPM`; $('online-opponent-wpm').textContent = `${Number(data.opponent_wpm || 0)} WPM`;
    $('online-my-progress').style.width = `${Math.min(100, myWords * 10)}%`;
    $('online-opponent-progress').style.width = `${Math.min(100, rivalWords * 10)}%`;
    const stats = data.my_stats;
    if (stats) { $('stat-wins').textContent = stats.wins; $('stat-losses').textContent = stats.losses; $('stat-played').textContent = stats.games_played; }
  }
  function showResult(data) {
    if (finished) { updateScores(data); return; }
    finished = true; active = false; input.disabled = true; $('forfeit-button').hidden = true;
    $('online-result').hidden = false;
    const won = data.i_won === true;
    const detail = `You: ${Number(data.my_words || wordIndex)}/10 words · ${Number(data.my_wpm || 0)} WPM. ${data.opponent || 'Rival'}: ${Number(data.opponent_words || 0)}/10 words · ${Number(data.opponent_wpm || 0)} WPM.`;
    $('online-result').innerHTML = `<strong>${won ? 'You won the duel!' : 'You lost this duel.'}</strong><span>${detail}</span>`;
    $('online-result-badge').textContent = won ? 'VICTORY' : 'DEFEAT';
    $('online-result-badge').className = `result-badge ${won ? 'victory-badge' : 'defeat-badge'}`;
    $('online-result-title').textContent = won ? 'Victory!' : 'Defeat';
    $('online-result-detail').textContent = detail;
    if (typeof $('online-result-dialog').showModal === 'function') $('online-result-dialog').showModal();
    $('rematch-button').hidden = false; $('return-lobby').hidden = false;
    updateScores(data); stopPolling(); clearError();
  }
  async function poll() {
    try {
      const data = await api('poll');
      if (data.status === 'playing' || data.status === 'completed') showMatch(data);
      else if (data.status === 'waiting') showWaiting(data);
      else { showIdle(); }
    } catch (e) { error(e.message); }
  }
  async function queue() {
    queueButton.disabled = true; clearError();
    if (music.paused) playMusic();
    try {
      const data = await api('join');
      if (data.status === 'playing' || data.status === 'completed') showMatch(data);
      else showWaiting(data);
      beginPolling();
    } catch (e) { error(e.message); queueButton.disabled = false; }
    finally { queueButton.disabled = false; }
  }
  queueButton.addEventListener('click', queue);
  cancelButton.addEventListener('click', async () => {
    cancelButton.disabled = true;
    try { await api('cancel'); showIdle(); } catch (e) { error(e.message); }
    finally { cancelButton.disabled = false; }
  });
  $('rematch-button').addEventListener('click', () => { matchId = 0; queue(); });
  $('online-play-again').addEventListener('click', () => { $('online-result-dialog').close(); matchId = 0; queue(); });
  $('forfeit-button').addEventListener('click', async () => {
    if (!active || !window.confirm('Forfeit this match? Your opponent will get the win.')) return;
    $('forfeit-button').disabled = true;
    try { showResult(await api('forfeit', { match_id: matchId })); }
    catch (e) { error(e.message); }
    finally { $('forfeit-button').disabled = false; }
  });
  input.addEventListener('input', () => {
    if (!active) return;
    const typed = input.value.trim().toLowerCase();
    input.classList.toggle('is-wrong', Boolean(typed && !words[wordIndex]?.word.startsWith(typed)));
  });
  input.addEventListener('keydown', async (event) => {
    if (/^[a-zA-Z0-9]$/.test(event.key) && active) tone(420 + Math.random() * 240, .035, .018);
    if (event.key !== ' ' && event.key !== 'Enter') return;
    event.preventDefault(); if (!active || !input.value.trim() || !words[wordIndex]) return;
    wordIndex++; paintWord();
    const elapsed = Math.max(1, (Date.now() - startedAt) / 1000);
    const wpm = Math.round((wordIndex * 5 / elapsed) * 60);
    $('online-my-wpm').textContent = `${wpm} WPM`;
    $('online-my-progress').style.width = `${wordIndex * 10}%`;
    try {
      const data = await api('progress', { match_id: matchId, words: wordIndex, wpm });
      updateScores(data);
      if (data.status === 'completed') showResult(data);
      else if (wordIndex >= 10) { active = false; input.disabled = true; }
    } catch (e) { error(e.message); }
  });
  $('stat-wins').textContent = Number($('stat-wins').textContent);
})();
