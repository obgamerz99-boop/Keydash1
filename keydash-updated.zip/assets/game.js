(() => {
  const wordsByLevel = {
    easy: ['sunny','little','green','happy','water','bright','smile','garden','warm','dream','apple','quiet','music','river','cloud','gentle','paper','fresh','table','kind'],
    medium: ['steady','journey','between','curious','morning','capture','another','balance','picture','forward','breathe','thought','perfect','natural','freedom','whisper','explore','without','purpose','careful'],
    hard: ['rhythm','awkward','zephyr','subtle','sphinx','vibrant','jigsaw','complex','oxygen','zealous','cryptic','knapsack','juxtapose','wavelength','quizzical','mischievous','phenomenon','labyrinth','exquisite','unfamiliar']
  };
  const body = document.body, mode = body.dataset.mode, level = body.dataset.level;
  const botWpm = Number(body.dataset.botWpm || 25), $ = (id) => document.getElementById(id);
  const input = $('typing-input'), target = $('target-word'), startButton = $('start-button');
  const restartButton = $('restart-button'), result = $('result');
  let words = [], index = 0, startedAt = 0, timerId = null, botTimerId = null;
  let botProgress = 0, correct = 0, errors = 0, running = false, saved = false;
  let audioContext = null;
  const music = $('background-music'), musicToggle = $('music-toggle'), musicVolume = $('music-volume');
  music.volume = Number(musicVolume.value) / 100;

  function audio() {
    if (!audioContext) audioContext = new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') audioContext.resume();
    return audioContext;
  }
  function tone(frequency, duration = .045, volume = .026, type = 'sine', offset = 0, force = false) {
    if (!force && $('typing-sound-toggle').getAttribute('aria-pressed') !== 'true') return;
    const ctx = audio(), oscillator = ctx.createOscillator(), gain = ctx.createGain();
    oscillator.type = type; oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(volume, ctx.currentTime + offset);
    gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + offset + duration);
    oscillator.connect(gain); gain.connect(ctx.destination);
    oscillator.start(ctx.currentTime + offset); oscillator.stop(ctx.currentTime + offset + duration);
  }
  function winnerSound(won) {
    const notes = won ? [523, 659, 784, 1047] : [392, 330];
    notes.forEach((note, i) => tone(note, .22, .038, 'triangle', i * (won ? .12 : .18), true));
  }
  function startMusic() {
    music.play().then(() => {
      musicToggle.setAttribute('aria-pressed', 'true');
      musicToggle.lastElementChild.textContent = 'ON';
      $('music-fallback').hidden = true;
    }).catch(() => {
      musicToggle.setAttribute('aria-pressed', 'false');
      musicToggle.lastElementChild.textContent = 'ADD MP3';
      $('music-fallback').hidden = false;
    });
  }
  musicToggle.addEventListener('click', () => {
    if (music.paused) startMusic();
    else { music.pause(); musicToggle.setAttribute('aria-pressed', 'false'); musicToggle.lastElementChild.textContent = 'OFF'; }
  });
  music.addEventListener('error', () => { musicToggle.setAttribute('aria-pressed', 'false'); musicToggle.lastElementChild.textContent = 'ADD MP3'; $('music-fallback').hidden = false; });
  music.addEventListener('pause', () => { musicToggle.setAttribute('aria-pressed', 'false'); if (musicToggle.lastElementChild.textContent === 'ON') musicToggle.lastElementChild.textContent = 'OFF'; });
  musicVolume.addEventListener('input', (event) => { music.volume = Number(event.target.value) / 100; });
  $('typing-sound-toggle').addEventListener('click', () => {
    const on = $('typing-sound-toggle').getAttribute('aria-pressed') !== 'true';
    $('typing-sound-toggle').setAttribute('aria-pressed', String(on));
    $('typing-sound-toggle').lastElementChild.textContent = on ? 'ON' : 'OFF';
    if (on) tone(660);
  });
  function pickWords() {
    const pool = [...wordsByLevel[level]];
    for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    return pool.slice(0, 10);
  }
  function showWord() {
    target.textContent = words[index] || 'Done!';
    target.classList.remove('word-pop'); void target.offsetWidth; target.classList.add('word-pop');
    $('word-number').textContent = String(Math.min(index + 1, 10)).padStart(2, '0');
    $('progress-count').innerHTML = `${index}<small>/10</small>`;
    input.value = ''; input.classList.remove('is-wrong');
    if (mode === 'race') $('player-words').textContent = `${index}/10`;
  }
  function elapsedSeconds() { return Math.max(.1, (Date.now() - startedAt) / 1000); }
  function currentWpm() { return Math.round((correct * 5 / elapsedSeconds()) * 60); }
  function updateStats() {
    const seconds = elapsedSeconds();
    $('timer').textContent = `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
    $('wpm').innerHTML = `${currentWpm()} <small>WPM</small>`;
    $('accuracy').innerHTML = `${Math.round(correct / Math.max(1, correct + errors) * 100)}<small>%</small>`;
    if (mode === 'race') $('player-wpm').textContent = `${currentWpm()} WPM`;
  }
  function animateProgress(el, progress) {
    el.style.width = `${Math.min(100, progress * 10)}%`;
    el.closest('.score-row')?.classList.add('score-active');
    setTimeout(() => el.closest('.score-row')?.classList.remove('score-active'), 420);
  }
  function begin() {
    if (timerId) clearInterval(timerId); if (botTimerId) clearInterval(botTimerId);
    words = pickWords(); index = 0; botProgress = 0; correct = 0; errors = 0; running = true; saved = false;
    result.hidden = true; startButton.hidden = true; restartButton.hidden = true; $('lobby-button').hidden = true; input.disabled = false;
    startMusic();
    $('wpm').innerHTML = '0 <small>WPM</small>'; $('accuracy').innerHTML = '100<small>%</small>'; $('timer').textContent = '0:00';
    startedAt = Date.now(); showWord(); input.focus();
    if (mode === 'race') {
      $('bot-status').textContent = 'RACING'; $('bot-words').textContent = '0/10';
      $('player-progress').style.width = '0%'; $('bot-progress').style.width = '0%';
      botTimerId = setInterval(() => {
        botProgress = Math.min(10, botProgress + botWpm / 60 / 4);
        $('bot-words').textContent = `${Math.min(10, Math.floor(botProgress))}/10`;
        animateProgress($('bot-progress'), botProgress);
        if (botProgress >= 10) finish(false);
      }, 250);
    }
    timerId = setInterval(updateStats, 250);
  }
  async function saveResult(won) {
    if (saved || body.dataset.loggedIn !== '1') return;
    saved = true;
    try {
      const response = await fetch('save_score.php', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': body.dataset.csrf }, body: JSON.stringify({ mode, level, wpm: currentWpm(), accuracy: Math.round(correct / Math.max(1, correct + errors) * 100), words_correct: correct, elapsed_ms: Math.min(3600000, Math.round(elapsedSeconds() * 1000)), won: won ? 1 : 0 }) });
      if (!response.ok) throw new Error('Score could not be saved');
      const data = await response.json();
      if (data.saved) $('round-leaderboard').hidden = false;
    } catch (error) { console.warn('Could not save this score.', error); }
  }
  function finish(playerWon = true) {
    if (!running) return;
    running = false; clearInterval(timerId); clearInterval(botTimerId); updateStats(); input.disabled = true;
    if (mode === 'race') {
      $('bot-status').textContent = playerWon ? 'FINISHED' : 'BOT FINISHED';
      $('player-words').textContent = `${index}/10`;
      if (playerWon) { animateProgress($('player-progress'), 10); $('player-words').textContent = '10/10'; }
    }
    const accuracy = Math.round(correct / Math.max(1, correct + errors) * 100);
    const headline = mode === 'race' ? (playerWon ? 'Victory!' : 'Defeat') : 'Round complete!';
    const detail = mode === 'race' ? `You: ${index}/10 words · ${currentWpm()} WPM · ${accuracy}% accuracy. Bot: ${Math.min(10, Math.floor(botProgress))}/10 words · ${botWpm} WPM.` : `You: ${correct}/10 correct · ${currentWpm()} WPM · ${accuracy}% accuracy.`;
    result.innerHTML = `<strong>${headline}</strong><span>${detail}</span>`;
    $('round-badge').textContent = mode === 'race' ? (playerWon ? 'VICTORY' : 'DEFEAT') : 'ROUND COMPLETE';
    $('round-badge').className = `result-badge ${mode === 'race' ? (playerWon ? 'victory-badge' : 'defeat-badge') : 'neutral-badge'}`;
    $('round-title').textContent = headline;
    $('round-detail').textContent = detail;
    $('round-leaderboard').hidden = true;
    restartButton.hidden = false; $('lobby-button').hidden = false; winnerSound(playerWon);
    if (typeof $('round-dialog').showModal === 'function') $('round-dialog').showModal();
    saveResult(playerWon);
  }
  startButton.addEventListener('click', begin); restartButton.addEventListener('click', begin);
  $('round-again').addEventListener('click', () => { $('round-dialog').close(); begin(); });
  $('round-close').addEventListener('click', () => $('round-dialog').close());
  input.addEventListener('keydown', (event) => {
    if (/^[a-zA-Z0-9]$/.test(event.key) && running) tone(420 + Math.random() * 240, .035, .018, 'square');
  });
  input.addEventListener('input', () => {
    if (!running) return;
    const typed = input.value.trim();
    if (typed && !words[index].startsWith(typed.toLowerCase())) input.classList.add('is-wrong'); else input.classList.remove('is-wrong');
  });
  input.addEventListener('keydown', (event) => {
    if (event.key !== ' ' && event.key !== 'Enter') return;
    event.preventDefault(); if (!running) return;
    const typed = input.value.trim(); if (!typed) return;
    if (typed.toLowerCase() === words[index].toLowerCase()) correct++; else errors++;
    index++;
    $('progress-count').innerHTML = `${index}<small>/10</small>`;
    if (mode === 'race') animateProgress($('player-progress'), index);
    updateStats();
    if (index >= words.length) finish(true); else showWord();
  });
})();
