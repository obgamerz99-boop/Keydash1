(() => {
  const dialog = document.createElement('dialog');
  dialog.className = 'confirm-dialog';
  dialog.innerHTML = '<div class="dialog-card"><span class="result-badge neutral-badge">KEYDASH</span><h2>Are you sure you want to log out?</h2><p>Your scores and profile will stay saved.</p><div class="dialog-actions"><button class="button button-quiet" type="button" data-cancel>Stay logged in</button><a class="button button-primary" href="logout.php">Log out</a></div></div>';
  document.body.append(dialog);
  dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
  dialog.querySelector('[data-cancel]').addEventListener('click', () => dialog.close());
  document.addEventListener('click', (event) => {
    const link = event.target.closest('a[href="logout.php"]');
    if (!link || link.closest('dialog')) return;
    event.preventDefault();
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
  });
})();
